package com.example.statuspherenew.friends

data class Friend(
    val name: String,
    val relationship: String
)