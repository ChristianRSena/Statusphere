package com.example.statuspherenew.groups

import androidx.lifecycle.ViewModel

class GroupsViewModel : ViewModel() {
    // ViewModel logic here
}
