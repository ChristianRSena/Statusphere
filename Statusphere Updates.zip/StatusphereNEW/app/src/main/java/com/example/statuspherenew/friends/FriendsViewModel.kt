package com.example.statuspherenew.friends

import androidx.lifecycle.ViewModel

class FriendsViewModel : ViewModel() {
    // ViewModel logic here
}
