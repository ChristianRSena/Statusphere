package com.example.statuspherenew.groups

data class Group(val id: Int, val name: String, val description: String)