package com.example.statuspherenew.login

import android.os.Bundle
import android.widget.EditText
import android.widget.Button
import android.widget.Toast // For making simple notifications
import androidx.appcompat.app.AppCompatActivity
import com.example.statuspherenew.R

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login) // Assuming you'll create the layout in XML

        // Initialize views
        val usernameEditText: EditText = findViewById(R.id.username)
        val passwordEditText: EditText = findViewById(R.id.password)
        val loginButton: Button = findViewById(R.id.loginButton)

        // Set up login button click listener
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Add your login logic here (input validation, authentication, etc.)
            if (isValidLogin(username, password)) {
                // Navigate to the next screen or perform actions on successful login
            } else {
                Toast.makeText(this, "Login failed!", Toast.LENGTH_SHORT).show()
            }
        }
    }
    // Simple placeholder function for login validation
    private fun isValidLogin(username: String, password: String): Boolean {
        // TODO: Add your actual validation logic
        return username.isNotEmpty() && password.isNotEmpty()
    }


}
